using Godot;
using System;

public partial class DebugOptions : PanelContainer
{	public NodePath PlayerPath;
	[Export] public float defaultRotationSpeed = 360f;
	[Export] public float defaultAirSpeed = 500f;
	[Export] public float defaultGravity = 9800f;
	[Export] public int defaultTrailMaxPoints = 500;
	[Export] public int defaultTrailSegmentLength = 30;
	public static bool ShowDebugOverlay = false;
	public static bool ShowAdvanced = false;

	public DebugCanvas mySceneInstance;
	OptionsMenu optionsMenu;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		optionsMenu = FindOptionsMenu();

		if (optionsMenu == null)
		{
			//GD.printErr("OptionsMenu not found in the current scene.");
			return;
		}
		//if (PlayerPath == null)
		//{
		////GD.printErr("PlayerPath is not set in the DebugOptions.");
		//return;
		//}
		//Player playerNode = GetNode<Player>(PlayerPath);

		Player playerNode = optionsMenu.FindPlayerNode();

		if (playerNode == null)
		{
			//GD.printErr($"Player node not found at path: {PlayerPath}");
			return;
		}
		PlayerPath = playerNode.GetPath();

		//playerNode.rotationSpeed = defaultRotationSpeed;
		//playerNode.airSpeed = defaultAirSpeed;
		//playerNode.gravity = defaultGravity;
		//playerNode.trailMaxPoints = defaultTrailMaxPoints;
		//playerNode.trailSegmentLength = defaultTrailSegmentLength;

		Settings gameSettings = GD.Load<Settings>("res://Settings.tres");
		if (gameSettings == null)
		{
			//GD.printErr("Failed to load Settings.tres");
			return;
		}

		gameSettings.PlayerPath = PlayerPath;
		ResourceSaver.Save(gameSettings, "res://Settings.tres");

		PackedScene debugOverlayScene = GD.Load<PackedScene>("res://Scenes/Debug.tscn");
		mySceneInstance = debugOverlayScene.Instantiate<DebugCanvas>();
		AddChild(mySceneInstance); // Adds to this node

		mySceneInstance.Visible = gameSettings.ShowDebug;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/ShowDebugOverlay").ButtonPressed = gameSettings.ShowDebug;
		ShowDebugOverlay = gameSettings.ShowDebug;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced1").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced2").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced3").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced4").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced5").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced6").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced1").ButtonPressed = gameSettings.debugOverlayAdvanced1;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced2").ButtonPressed = gameSettings.debugOverlayAdvanced2;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced3").ButtonPressed = gameSettings.debugOverlayAdvanced3;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced4").ButtonPressed = gameSettings.debugOverlayAdvanced4;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced5").ButtonPressed = gameSettings.debugOverlayAdvanced5;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced6").ButtonPressed = gameSettings.debugOverlayAdvanced6;
		mySceneInstance.ShowFPS = gameSettings.debugOverlayAdvanced1;
		mySceneInstance.showPrc = gameSettings.debugOverlayAdvanced2;
		mySceneInstance.showPhy = gameSettings.debugOverlayAdvanced3;
		mySceneInstance.showNav = gameSettings.debugOverlayAdvanced4;
		mySceneInstance.showTSz = gameSettings.debugOverlayAdvanced5;
		mySceneInstance.showTTm = gameSettings.debugOverlayAdvanced6;
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer/HBoxContainer/SpinBox").Value = gameSettings.playerRotationSpeed;
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer2/HBoxContainer/SpinBox").Value = gameSettings.playerAirSpeed;
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer3/HBoxContainer/SpinBox").Value = gameSettings.playerGravity;
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer4/HBoxContainer/SpinBox").Value = gameSettings.playerTrailMaxPoints;
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer5/HBoxContainer/SpinBox").Value = gameSettings.playerTrailSegmentLength;
		//GetNode<Button>("CanvasLayer/TabContainer/Debug/ShowVelocity").ButtonPressed = gameSettings.ShowVelocity;
		//GetNode<Button>("CanvasLayer/TabContainer/Debug/ShowTrail").ButtonPressed = gameSettings.Showtrail;
	}

	// Find the nearest OptionsMenu ancestor in the tree
	private OptionsMenu FindOptionsMenu()
	{
		Node node = this;
		while (node != null)
		{
			if (node is OptionsMenu om)
				return om;
			node = node.GetParent();
		}
		return null;
	}

	public void _on_show_debug_overlay_toggled(bool button_pressed)
	{
		ShowDebugOverlay = button_pressed;
		ShowAdvanced = button_pressed;
		mySceneInstance.Visible = button_pressed;

		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced1").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced2").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced3").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced4").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced5").Visible = ShowAdvanced;
		GetNode<Button>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/Advanced6").Visible = ShowAdvanced;

	}
	public void _on_advanced_1_toggled(bool button_pressed)
	{

		if (mySceneInstance != null)
		{

			mySceneInstance.ShowFPS = button_pressed;

		}

	}
	public void _on_advanced_2_toggled(bool button_pressed)
	{
		if (mySceneInstance != null)
		{
			mySceneInstance.showPrc = button_pressed;
		}
	}
	public void _on_advanced_3_toggled(bool button_pressed)
	{
		if (mySceneInstance != null)
		{
			mySceneInstance.showPhy = button_pressed;
		}
	}
	public void _on_advanced_4_toggled(bool button_pressed)
	{
		if (mySceneInstance != null)
		{
			mySceneInstance.showNav = button_pressed;
		}
	}
	public void _on_advanced_5_toggled(bool button_pressed)
	{
		if (mySceneInstance != null)
		{
			mySceneInstance.showTSz = button_pressed;
		}
	}
	public void _on_advanced_6_toggled(bool button_pressed)
	{
		if (mySceneInstance != null)
		{
			mySceneInstance.showTTm = button_pressed;
		}
	}
	private void _on_spin_box_value_changed(float value)
	{
		optionsMenu.playerRotationS = value;
	}
	private void _on_spin_box2_value_changed(float value)
	{
		optionsMenu.playerAirS = value;
	}
	private void _on_spin_box3_value_changed(float value)
	{
		optionsMenu.playerG = value;
	}
	private void _on_spin_box4_value_changed(float value)
	{
		optionsMenu.playerTrailMaxP = (int)value;
	}
	private void _on_spin_box5_value_changed(float value)
	{
		optionsMenu.playerTrailSegmentL = value;
	}
	private void _on_reset_button1_pressed()
	{
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer/HBoxContainer/SpinBox").Value = defaultRotationSpeed;
		optionsMenu.playerRotationS = defaultRotationSpeed;
	}
	private void _on_reset_button2_pressed()
	{
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer2/HBoxContainer/SpinBox").Value = defaultAirSpeed;
		optionsMenu.playerAirS = defaultAirSpeed;
	}
	private void _on_reset_button3_pressed()
	{
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer3/HBoxContainer/SpinBox").Value = defaultGravity;
		optionsMenu.playerG = defaultGravity;
	}
	private void _on_reset_button4_pressed()
	{
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer4/HBoxContainer/SpinBox").Value = defaultTrailMaxPoints;
		optionsMenu.playerTrailMaxP = defaultTrailMaxPoints;
	}
	private void _on_reset_button5_pressed()
	{
		GetNode<SpinBox>("MarginContainer/VBoxContainer/ScrollContainer/VBoxContainer/MarginContainer/HBoxContainer/VBoxContainer/MarginContainer5/HBoxContainer/SpinBox").Value = defaultTrailSegmentLength;
		optionsMenu.playerTrailSegmentL = defaultTrailSegmentLength;
	}
}
